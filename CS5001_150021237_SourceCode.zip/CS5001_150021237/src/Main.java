import core.IcyWrench;

/**
 * Runs the IcyWebsever.
 * @author 150021237
 *
 */
public class Main {

	public static void main(String[] args) {
		new IcyWrench();
	}
}
